﻿using System.Collections.Generic;
using UnityEngine;

public class ConveyorController : MonoBehaviour
{
    public static ConveyorController Instance;

    [Header("Conveyor Settings")]
    public float beltSpeed = 1.5f;

    public bool debugLogs = false;

    // List of cones currently on the belt
    public List<GameObject> conesOnBelt = new();

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    private void Update()
    {
        MoveConesOnBelt();
    }

    public void Init(float speed)
    {
        beltSpeed = speed;
        if (debugLogs) Debug.Log("Conveyor speed set to: " + beltSpeed);
    }

    public void EnqueueFinishedCone(GameObject cone)
    {
        if (cone == null) return;

        // Detach from parent
        cone.transform.SetParent(null);

        // Align Y height
        Vector3 pos = cone.transform.position;
        pos.y = transform.position.y;
        cone.transform.position = pos;

        conesOnBelt.Add(cone);

        if (debugLogs)
            Debug.Log("Added cone: " + cone.name);
    }

    private void MoveConesOnBelt()
    {
        // Clean up missing objects
        conesOnBelt.RemoveAll(item => item == null);

        if (debugLogs && conesOnBelt.Count > 0)
            Debug.Log("Moving cones: " + conesOnBelt.Count);

        for (int i = 0; i < conesOnBelt.Count; i++)
        {
            var cone = conesOnBelt[i];
            if (cone == null) continue;

            Vector3 pos = cone.transform.position;

            // Lock Y height
            pos.y = transform.position.y;

            // Apply conveyor movement
            pos += Vector3.left * beltSpeed * Time.deltaTime;

            cone.transform.position = pos;

            if (debugLogs)
                Debug.Log($"Cone {cone.name} moved to {pos}");
        }
    }
}
