using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeliveryManager : MonoBehaviour
{
    public static DeliveryManager Instance { get; private set; }

    [Tooltip("Prefab for customer GameObjects (should have CustomerController).")]
    public GameObject customerPrefab;

    [Tooltip("Spawn position where new customers will wait near exit.")]
    public Transform customerSpawnPoint;

    [Tooltip("Exit position where customers walk off after being served.")]
    public Transform customerExitPoint;

    [Tooltip("Maximum customers in queue.")]
    public int maxQueue = 3;

    private Queue<CustomerController> customerQueue = new Queue<CustomerController>();
    private CustomerController activeCustomer = null;

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    private void Start()
    {
        // Pre-fill initial customers
        for (int i = 0; i < maxQueue; i++) SpawnCustomerToQueue();
    }

    private void SpawnCustomerToQueue()
    {
        if (customerPrefab == null || customerSpawnPoint == null) return;
        var go = Instantiate(customerPrefab, customerSpawnPoint.position, Quaternion.identity, transform);
        var controller = go.GetComponent<CustomerController>();
        if (controller == null)
            controller = go.AddComponent<CustomerController>();

        // Provide world positions (Vector3) for stand and exit
        Vector3 standPos = customerSpawnPoint.position;
        Vector3 exitPos = customerExitPoint != null ? customerExitPoint.position : (customerSpawnPoint.position + Vector3.right * 2f);

        controller.SetPositions(standPos, exitPos);
        customerQueue.Enqueue(controller);

        // If no active customer, move next to receive point
        if (activeCustomer == null) MoveNextCustomerToReceivePoint();
    }

    private void MoveNextCustomerToReceivePoint()
    {
        if (customerQueue.Count == 0) SpawnCustomerToQueue();
        if (customerQueue.Count == 0) return;

        activeCustomer = customerQueue.Dequeue();
        // tell customer to move to receive point and wait to be served
        activeCustomer.MoveToReceivePoint();
        // spawn one more to maintain queue
        SpawnCustomerToQueue();
    }

    // Called by Conveyor/ConveyorController after a cone reaches receive point
    public void DeliverCone(GameObject cone)
    {
        if (activeCustomer == null)
        {
            // wait a frame and try again
            StartCoroutine(WaitAndTryDeliver(cone));
            return;
        }

        // Give cone to active customer
        activeCustomer.ReceiveCone(cone, () =>
        {
            // callback after customer takes cone and leaves
            activeCustomer = null;
            MoveNextCustomerToReceivePoint();
        });
    }

    private IEnumerator WaitAndTryDeliver(GameObject cone)
    {
        // small wait to let customer become active
        yield return new WaitForSeconds(0.15f);
        DeliverCone(cone);
    }

    // --------- Backwards-compatible Deliver overloads ---------

    // Single cone API (used by older code)
    public void Deliver(ConeController cone)
    {
        if (cone == null) return;

        Debug.Log("DeliveryManager.Deliver(ConeController) called.");

        // Convert the cone GameObject and hand it to a customer if one is active
        if (activeCustomer != null)
        {
            // hand off using the cone's GameObject
            activeCustomer.ReceiveCone(cone.gameObject, () =>
            {
                activeCustomer = null;
                MoveNextCustomerToReceivePoint();
            });
        }
        else
        {
            // If no active customer, enqueue movement: use conveyor to move it to receive point
            ConveyorController.Instance?.EnqueueFinishedCone(cone.gameObject);
        }
    }

    // New: accept a list/pack of cones (Tray)
    public void Deliver(List<ConeController> cones)
    {
        if (cones == null || cones.Count == 0) return;
        Debug.Log($"DeliveryManager.Deliver(List<ConeController>) called with {cones.Count} cones.");

        // Deliver cones one-by-one: prefer giving to active customer if present, otherwise route via conveyor.
        foreach (var c in cones)
        {
            if (c == null) continue;

            if (activeCustomer != null)
            {
                // If there's an active customer, hand one cone (for demonstration we hand the first)
                activeCustomer.ReceiveCone(c.gameObject, () =>
                {
                    activeCustomer = null;
                    MoveNextCustomerToReceivePoint();
                });
            }
            else
            {
                // Move cone to conveyor so normal flow will deliver it
                ConveyorController.Instance?.EnqueueFinishedCone(c.gameObject);
            }
        }
    }
}
