using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PipeController : MonoBehaviour
{
    public enum RandomizeMode { OnLevelStart, OnEveryScoop, Interval }
    public RandomizeMode randomizeMode = RandomizeMode.OnLevelStart;

    [Tooltip("List of possible flavors this pipe can output.")]
    public List<FlavorType> possibleFlavors = new List<FlavorType>();

    [Tooltip("Reference to a Renderer used to tint the pipe for visual feedback.")]
    public Renderer pipeRenderer;

    [Tooltip("Interval in seconds when using Interval mode.")]
    public float intervalSeconds = 2f;

    public FlavorType CurrentFlavor { get; private set; }

    public static event Action<PipeController, FlavorType> OnPipeFlavorChanged;

    private Coroutine intervalRoutine;

    private void Start()
    {
        if (randomizeMode == RandomizeMode.OnLevelStart)
            RandomizeFlavor();

        if (randomizeMode == RandomizeMode.Interval)
            intervalRoutine = StartCoroutine(IntervalRandomize());
    }

    private void OnEnable()
    {
        // If other systems want to trigger randomization after each scoop:
        ConeController.OnScoopPlaced += HandleScoopPlaced;
    }

    private void OnDisable()
    {
        ConeController.OnScoopPlaced -= HandleScoopPlaced;
        if (intervalRoutine != null) StopCoroutine(intervalRoutine);
    }

    private void HandleScoopPlaced(ConeController cone, FlavorType addedFlavor)
    {
        if (randomizeMode == RandomizeMode.OnEveryScoop)
            RandomizeFlavor();
    }

    private IEnumerator IntervalRandomize()
    {
        while (true)
        {
            yield return new WaitForSeconds(intervalSeconds);
            RandomizeFlavor();
        }
    }

    [ContextMenu("Randomize Flavor")]
    public void RandomizeFlavor()
    {
        if (possibleFlavors == null || possibleFlavors.Count == 0) return;
        int idx = UnityEngine.Random.Range(0, possibleFlavors.Count);
        CurrentFlavor = possibleFlavors[idx];
        UpdateVisual();
        OnPipeFlavorChanged?.Invoke(this, CurrentFlavor);
    }

    private void UpdateVisual()
    {
        if (pipeRenderer == null) return;

        // Map flavor to a color; adjust mapping to match your project
        Color col = FlavorColorMap.GetColorForFlavor(CurrentFlavor);
        // Use material property if needed
        if (pipeRenderer.material != null)
            pipeRenderer.material.color = col;
    }

    // For other scripts to request flavor (e.g. when dispensing)
    public FlavorType DispenseFlavor()
    {
        // Optionally re-randomize here if you want unpredictability at moment of dispense:
        if (randomizeMode == RandomizeMode.OnEveryScoop)
            RandomizeFlavor();

        // Return current flavor
        return CurrentFlavor;
    }

    public void SetPouring(bool state)
    {
        Debug.Log("Pipe pouring: " + state);
    }
}
