public enum FlavorType
{
    Vanilla = 0,
    Chocolate = 1,
    Strawberry = 2,
    Mint = 3
}
