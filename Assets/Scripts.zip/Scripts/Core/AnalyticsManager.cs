using UnityEngine;

public class AnalyticsManager : Singleton<AnalyticsManager>
{
   
}
