using UnityEngine;


public class AudioManager : Singleton<AudioManager>
{
    // your audio logic here
}
