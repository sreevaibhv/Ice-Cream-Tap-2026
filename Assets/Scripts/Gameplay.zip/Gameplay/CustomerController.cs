using System;
using System.Collections;
using UnityEngine;

public class CustomerController : MonoBehaviour
{
    // positions in world space
    private Vector3 standPosition;
    private Vector3 exitPosition;

    public float moveSpeed = 3f;
    public Animator animator;
    public float WaitTimer= 4f;
    private bool OrderReceive = false;
    private bool atReceivePoint = false;

    // Accept two world positions (stand and exit)
    public void SetPositions(Vector3 stand, Vector3 exit)
    {
        standPosition = stand;
        exitPosition = exit;
        //transform.position = standPosition;
    }

    // Move to the receive point (we'll just step forward a bit to simulate)
    public void MoveToReceivePoint()
    {
        // In a more advanced implementation you'd tween/move smoothly.
        // For compatibility with DeliveryManager we will move instantly or via coroutine.
        StopAllCoroutines();
        StartCoroutine(MoveTo(standPosition + Vector3.left * 0.4f, () =>
        {
            atReceivePoint = true;
            if (animator != null) animator.Play("Idle");
        }));
        StartCoroutine(WaitForOrder());
    }

    private IEnumerator WaitForOrder()
    {
        yield return new WaitForSeconds(WaitTimer);
        if(!OrderReceive)
        {
            StartCoroutine(MoveTo(exitPosition));
            DeliveryManager.Instance.MoveNextCustomerToReceivePoint();
        }
    }

    // This receives the cone GameObject and invokes callback after 'taking' it.
    public void ReceiveCone(GameObject cone, Action onComplete)
    {
        if (!atReceivePoint)
        {
            // small retry timeout
            StartCoroutine(DelayedReceive(cone, onComplete));
            return;
        }

        StopAllCoroutines();
        StartCoroutine(ProcessReceive(cone, onComplete));
    }

    private IEnumerator DelayedReceive(GameObject cone, Action onComplete)
    {
        yield return new WaitForSeconds(0.15f);
        ReceiveCone(cone, onComplete);
    }

    private IEnumerator ProcessReceive(GameObject cone, Action onComplete)
    {
        // play 'take' animation if exists
        if (animator != null) animator.Play("Take");

        // wait for animation (tweak)
        yield return new WaitForSeconds(0.45f);

        // destroy or pool the cone
        if (cone != null) Destroy(cone);

        // small pause
        yield return new WaitForSeconds(0.2f);

        // walk off
        yield return StartCoroutine(MoveTo(exitPosition, () =>
        {
            // after exit, destroy this customer or return to pool
            Destroy(gameObject);
            onComplete?.Invoke();
        }));
    }

    private IEnumerator MoveTo(Vector3 target, Action onArrive = null)
    {
        while (Vector3.Distance(transform.position, target) > 0.05f)
        {
            transform.position = Vector3.MoveTowards(transform.position, target, moveSpeed * Time.deltaTime);
            yield return null;
        }
        onArrive?.Invoke();
    }
}
