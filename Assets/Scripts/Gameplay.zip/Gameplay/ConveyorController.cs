﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConveyorController : MonoBehaviour
{
    public static ConveyorController Instance;

    [Header("Conveyor Settings")]
    public float beltSpeed = 1.5f;

    // FIX: List instead of Queue
    public List<GameObject> conesOnBelt = new();
   
    private void Awake()
    {
        Instance = this;
    }

    private void Update()
    {
        MoveConesOnBelt();
    }

    public void EnqueueFinishedCone(GameObject cone)
    {
        if (cone == null) return;

        // Detach from parent so their scripts don't overwrite movement
        //cone.transform.SetParent(null);

        // Ensure cone matches belt height
        Vector3 pos = cone.transform.position;
        //pos.y = transform.position.y;
        cone.transform.position = pos;
        Debug.Log(cone.name);
        conesOnBelt.Add(cone);
    }
    public void Init(float speed)
    {
        beltSpeed = speed;
        Debug.Log("Conveyor speed set to: " + beltSpeed);
    }
    public void MoveConesOnBelt()
    {
    //if (conesOnBelt.Count > 0)
        Debug.Log("Moving cones: " + conesOnBelt.Count);

    for (int i = 0; i < conesOnBelt.Count; i++)
    {
        var cone = conesOnBelt[i];
        if (cone == null) continue;

        Debug.Log("Before move: " + cone.transform.position);

            // Move
            cone.transform.Translate(Vector3.right * beltSpeed * Time.deltaTime);
            Debug.Log("Speed: " + beltSpeed);
            Debug.Log("After move: " + cone.transform.position);
    }
   }
}
